1일차 실습 자료 — 교육용 가상 데이터

1. ZIP을 C:\ax-lab 등 새 실습 폴더에 풀어 주세요.
2. Claude Desktop의 Code > Local에서 그 폴더를 선택합니다.
3. sample-ok.xlsx: A라인 100개 중 4개, B라인 200개 중 2개 불량.
   전체 불량률 = 6/300 = 2%, A라인 = 4/100 = 4%.
4. sample-missing.xlsx: 불량수 열이 빠진 오류 확인용 파일.
5. .mcp.json: Windows용 Playwright MCP 설정. Node.js LTS 필요.
   기존 파일이 있다면 덮어쓰지 말고 mcpServers에 playwright만 추가합니다.
   새 Code 세션에서 서버 사용을 승인하고 /mcp로 연결을 확인합니다.

이 자료에는 완성 앱이 없습니다. 역인터뷰로 PRD를 작성하고 직접 구현합니다.
실제 회사 데이터나 개인정보가 포함되지 않은 수업용 자료입니다.
